from django.urls import path
from . import views
urlpatterns=[
    path("",views.index,name="index"),
    path("<str:number>/",views.tax_cal,name="tax_cal"),
    path("tax_rate/",views.tax_rate,name="tax_rate")
]